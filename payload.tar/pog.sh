#!/bin/sh

/usr/bin/wget --no-check-certificate "https://api.open-meteo.com/v1/forecast?latitude=64.4164&longitude=40.8167&hourly=temperature_2m&current=temperature_2m,relative_humidity_2m,surface_pressure,uv_index&timezone=Europe%2FMoscow&forecast_days=1" -O /tmp/shm/pogoda.json