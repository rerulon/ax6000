#!/bin/sh

FILE="/tmp/shm/pogoda.json"
RESPONSE_FILE="/tmp/shm/response14.txt"
URL_BASE="http://192.168.1.14/control?cmd=event,internetpog"

# Извлекаем значения из JSON
temp=$(jq -r '.current.temperature_2m' "$FILE")
humidity=$(jq -r '.current.relative_humidity_2m' "$FILE")
pressure=$(jq -r '.current.surface_pressure' "$FILE")
uv=$(jq -r '.current.uv_index' "$FILE")

# Проверка диапазона влажности
if [ "$humidity" -ge 0 ] && [ "$humidity" -le 100 ]; then
    attempt=1
    success=0
    while [ $attempt -le 4 ]; do
        wget -q -O "$RESPONSE_FILE" "$URL_BASE=$temp,$humidity,$pressure,$uv"
        
        if [ "$(cat "$RESPONSE_FILE")" = "OK" ]; then
            echo "Данные успешно отправлены"
            success=1
            break
        else
            echo "Попытка $attempt неудачна"
            if [ $attempt -lt 4 ]; then
                sleep 30
            fi
        fi
        attempt=$((attempt+1))
    done

    if [ $success -eq 0 ]; then
        echo "Ошибка отправки данных в ESP"
    fi
else
    echo "Ошибка получения данных"
fi
